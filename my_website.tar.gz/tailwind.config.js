/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./build/*.html"],
  theme: {
    container: {
      center: true
    },

    extend: {
    },
  },
  plugins: [],
}

